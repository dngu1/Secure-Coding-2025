// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
// Dylan Ngu
// CS-405 Module 2 - Bufferr Overflow
//

#include <iomanip>
#include <iostream>
#include <string>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
  //  even though it is a constant and the compiler buffer overflow checks are on.
  //  You need to modify this method to prevent buffer overflow without changing the account_number
  //  variable, and its position in the declaration. It must always be directly before the variable used for input.
  //  You must notify the user if they entered too much data.

  const int max_input_size = 20;

  const std::string account_number = "CharlieBrown42";
  char user_input[max_input_size];

  std::cout << "Enter a value: ";
  
  // using getline() to read user input and setting bufferr limit to 20
  // if input is longer than max_input_size, handle buffer overflow error
  std::cin.getline(user_input, max_input_size);

  // conditional statement to detect and handle buffer overflow
  if (std::cin.fail()) // cin.fail() returns true if input exceeds buffer
  {
    std::cout <<std::endl << "Error: Input too long, Buffer Overflow detected. Input will be stripped of extra characters." << std::endl;
    std::cin.clear(); // Clear error flags
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n'); // Discard characters after buffer limit
  }

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
