// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    if (count > 0){
      for (auto i = 0; i < count; ++i)
        collection->push_back(rand() % 100);
    }  
  }
};

// Test fixture to test multiple entry sizes based on parameters
struct ParamCollectionTest : CollectionTest, testing::WithParamInterface<int> {
  ParamCollectionTest() {}
};

// intantiate values for parameterized tests
INSTANTIATE_TEST_SUITE_P(CollectionTest, ParamCollectionTest, testing::Values(0, 1, 5, 10));

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer 
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}
*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  add_entries(1);

  // is the collection still empty?
  ASSERT_FALSE(collection->empty());
  // if not empty, what must the size be?
  ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  add_entries(5);

  // is the collection still empty?
  ASSERT_FALSE(collection->empty());
  // if not empty, what must the size be?
  ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_P(ParamCollectionTest, MaxSizeGreaterOrEqualSize) 
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entries based on parameter
  add_entries(GetParam());

  // verify entires were added
  ASSERT_EQ(collection->size(), GetParam());
  // verify max size is greater than or equal to size for parameter value
  ASSERT_GE(collection->max_size(), collection->size());
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_P(ParamCollectionTest, CapacityGreaterOrEqualSize) 
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entries based on parameter
  add_entries(GetParam());

  // verify entires were added
  ASSERT_EQ(collection->size(), GetParam());
  // verify capacity is greater than or equal to size for parameter value
  ASSERT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollection)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // resize collection
  collection->resize(1);

  // verify collection size equals 1
  ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollection)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entries
  add_entries(2);
  // verify collection size equals 2
  EXPECT_EQ(collection->size(), 2);

  // resize to 1 to decrease collection size
  collection->resize(1);

  // verify collection size decreased
  ASSERT_EQ(collection->size(), 1);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeDecreasesCollectionToZero)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entires
  add_entries(2);
  // verify collection size equals 2
  EXPECT_EQ(collection->size(), 2);

  // resize to 0 to decrease collection size to zero
  collection->resize(0);

  // verify collection size is zero
  ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, ClearErasesCollection)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entires
  add_entries(2);
  // verify collection size equals 2
  EXPECT_EQ(collection->size(), 2);

  // resize to 0 to decrease collection size to zero
  collection->clear();

  // verify collection is empty
  ASSERT_TRUE(collection->empty());
  // verify collection size is zero
  ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseErasesCollection)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entires
  add_entries(2);
  // verify collection size equals 2
  EXPECT_EQ(collection->size(), 2);

  // erase from begin to end
  collection->erase(collection->begin(), collection->end());

  // verify collection is empty
  ASSERT_TRUE(collection->empty());
  // verify collection size is zero
  ASSERT_EQ(collection->size(), 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacity)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);
  // verify capacity is zero
  EXPECT_EQ(collection->capacity(), 0);

  // reserve to increase capacity
  collection->reserve(2);

  // verify collection size is unchanged
  ASSERT_EQ(collection->size(), 0);
  // verify capacity increased
  ASSERT_EQ(collection->capacity(), 2);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
TEST_F(CollectionTest, AtUsingIndexOutOfBounds)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entires
  add_entries(2);
  // verify collection size equals 2
  EXPECT_EQ(collection->size(), 2);

  // verify std::out_of_range exception is thrown
  ASSERT_THROW(collection->at(3), std::out_of_range);
}
// NOTE: This is a negative test

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// Test to verify assign replaces container element with new one
TEST_F(CollectionTest, AssignReplacesElement)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // use assign to add 1 element with a value of 10
  collection->assign(1, 10);

  // verify collection isn't empty
  ASSERT_FALSE(collection->empty());
  // verify collection size is 1
  ASSERT_EQ(collection->size(), 1);
  // verify value is 10
  ASSERT_EQ(collection->at(0), 10);
}

// test to verify pop_back() reduces size of 
TEST_F(CollectionTest, PopBackReducesSize)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // add entires
  add_entries(2);
  // verify collection size equals 2
  EXPECT_EQ(collection->size(), 2);

  // pop_back() to remove last element
  collection->pop_back();

  // verify collection is not empty
  ASSERT_FALSE(collection->empty());
  // verify collection size is 1
  ASSERT_EQ(collection->size(), 1);
}

// test to verify the std::length_error exception is thrown when using reserve() to allocate too large amount of memory
TEST_F(CollectionTest, AllocateLargeMemoryUsingReserve)
{
  // verify collection is empty
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(), 0);

  // verify std::out_of_range exception is thrown
  ASSERT_THROW(collection->reserve(collection->max_size() + 1), std::length_error);
}